// =====================================================================
// RS_Roll -- shared tier system, dice utilities, and Condition mechanics
// ---------------------------------------------------------------------
// Everything in this file is universal across every future weapon type,
// not just revolvers. Weapon-specific stat RANGES (what a Revolver
// rolls for Damage at Uncommon tier, etc.) live in each weapon's own
// masterclass file -- this file only holds what every weapon shares:
// the tier ladder, socket counts per tier, generic dice helpers, and
// the Condition curve (backfire risk, degradation, repair).
// =====================================================================

enum EVR_Tier
{
	VRT_Cursed,
	VRT_Trash,
	VRT_Basic,
	VRT_Common,
	VRT_Uncommon,
	VRT_Advanced,
	VRT_Designer,
	VRT_Prototype
}

class RS_Roll : Object
{
	// -------------------------------------------------------------
	// Generic dice. Every weapon's RollStats() calls through these
	// instead of calling Random()/FRandom() directly, so there's one
	// place to swap the underlying RNG later if it's ever needed
	// (e.g. a seeded roll for a specific Unique weapon).
	// -------------------------------------------------------------
	static int RollInt(int lo, int hi)
	{
		return Random(lo, hi);
	}

	static double RollDouble(double lo, double hi)
	{
		return FRandom(lo, hi);
	}

	// -------------------------------------------------------------
	// GunBonai sockets per tier -- universal across weapon types.
	// Cursed/Trash/Basic get none; Common through Prototype scale 1-5.
	// -------------------------------------------------------------
	static int SocketsForTier(EVR_Tier t)
	{
		switch (t)
		{
			case VRT_Cursed:    return 0;
			case VRT_Trash:     return 0;
			case VRT_Basic:     return 0;
			case VRT_Common:    return 1;
			case VRT_Uncommon:  return 2;
			case VRT_Advanced:  return 3;
			case VRT_Designer:  return 4;
			case VRT_Prototype: return 5;
			default:            return 0;
		}
	}

	// -------------------------------------------------------------
	// Condition mechanics.
	// -------------------------------------------------------------

	// Repair: this many Grey Bits raises Condition by 1 point.
	const GREY_BITS_PER_CND_POINT = 10;

	// Degradation: any single hit dealing this much raw damage or more
	// drops Condition by this amount on every currently-equipped
	// weapon (both hands), regardless of which hand was firing.
	const CND_DAMAGE_THRESHOLD = 20;
	const CND_LOSS_PER_HIT = 3;

	// How many Condition points one Grey Bit spend restores.
	static double RepairCondition(double currentCnd, int greyBitsSpent)
	{
		double gained = double(greyBitsSpent) / double(GREY_BITS_PER_CND_POINT);
		return min(100.0, currentCnd + gained);
	}

	// Call this whenever the player takes a hit, for each currently
	// equipped weapon (both hands, independently -- the hit landed on
	// the player, not on a specific gun, so both take it).
	static double DegradeCondition(double currentCnd, int rawDamageTaken)
	{
		if (rawDamageTaken >= CND_DAMAGE_THRESHOLD)
			return max(0.0, currentCnd - CND_LOSS_PER_HIT);
		return currentCnd;
	}

	// Condition-band performance modifiers. Called right before a shot
	// resolves. Bands 80-100 are penalty-free; below that, performance
	// degrades, and below 50 there's a real chance of the weapon
	// "rolling well" instead -- more damage and pellets, but with a
	// backfire risk that climbs the further gone the weapon is. This
	// is deliberately not a reliable buff to farm: the good outcome is
	// itself a roll, not guaranteed.
	static void GetConditionEffects(double cnd, out double dmgMult, out double pelletMult, out double backfireChance)
	{
		dmgMult = 1.0;
		pelletMult = 1.0;
		backfireChance = 0.0;

		if (cnd >= 80.0)
		{
			return; // 80-100: no penalties
		}
		else if (cnd >= 70.0)
		{
			dmgMult = 0.95; // slight penalty
		}
		else if (cnd >= 60.0)
		{
			dmgMult = 0.90; // moderate penalty
		}
		else if (cnd >= 50.0)
		{
			dmgMult = 0.85; // heavier penalty, first flicker of instability
			backfireChance = 0.05;
		}
		else if (cnd >= 40.0)
		{
			// 20% chance of +1-pellet-equivalent (2x pellet mult on a
			// 1-pellet base weapon) at the cost of -30% damage; otherwise
			// just a straight damage penalty.
			if (RollDouble(0, 1) < 0.20)
			{
				pelletMult = 2.0;
				dmgMult = 0.70;
			}
			else
			{
				dmgMult = 0.80;
			}
		}
		else if (cnd >= 30.0)
		{
			if (RollDouble(0, 1) < 0.30)
			{
				pelletMult = 2.0;
				dmgMult = 0.65;
			}
			else
			{
				dmgMult = 0.75;
			}
			backfireChance = 0.15;
		}
		else if (cnd >= 20.0)
		{
			dmgMult = 1.25;
			pelletMult = 1.25;
			backfireChance = 0.40;
		}
		else if (cnd >= 10.0)
		{
			dmgMult = 1.5;
			pelletMult = 1.5;
			backfireChance = 0.60;
		}
		else // 1-9
		{
			dmgMult = 2.0;
			pelletMult = 2.0;
			backfireChance = 0.75;
		}
	}
}
